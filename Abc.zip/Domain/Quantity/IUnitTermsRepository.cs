﻿using Abc.Domain.Common;

namespace Abc.Domain.Quantity
{
    public interface IUnitTermsRepository : IRepository<UnitTerm> { }
}
