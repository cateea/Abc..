﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Abc.Tests.Infra
{
    [TestClass]
    public class UniqueEntityRepositoryTests
    {
    }
}