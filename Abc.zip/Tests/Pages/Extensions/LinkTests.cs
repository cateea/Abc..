﻿using Abc.Pages.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Abc.Tests.Pages.Extensions
{
    [TestClass]
    public class LinkTests : BaseTests
    {
        [TestInitialize] public virtual void TestIntialize() => type = typeof(Link);

        [TestMethod]
        public void DisplayNameTest()
        {
            Assert.Inconclusive();
        }
        [TestMethod]
        public void UrlTest()
        {
            Assert.Inconclusive();
        }
        [TestMethod]
        public void PropertyNameTest()
        {
            Assert.Inconclusive();
        }
    }
}