﻿using Abc.Pages.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Abc.Tests.Pages.Extensions
{
    [TestClass]
    public class DropDownNavigationMenuForHtmlExtensionTests : BaseTests
    {
        [TestInitialize] public virtual void TestIntialize() => type = typeof(DropDownNavigationMenuForHtmlExtension);

        [TestMethod]
        public void DropDownNavigationMenuForTest()
        {
            Assert.Inconclusive();
        }
    }
}